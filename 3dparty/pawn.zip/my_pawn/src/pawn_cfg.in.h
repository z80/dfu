
#ifndef __PAWN_CFG_H_
#define __PAWN_CFG_H_

#define STACK_SZ ${STACK_SIZE}
#define POOL_SZ  ${POOL_SIZE}

#endif